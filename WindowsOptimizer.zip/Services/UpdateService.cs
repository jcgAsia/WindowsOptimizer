using Squirrel;
using System;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;

namespace WindowsOptimizer.Services
{
    public class UpdateService
    {
        private static readonly Lazy<UpdateService> _instance = new Lazy<UpdateService>(() => new UpdateService());
        public static UpdateService Instance => _instance.Value;

        private Timer _timer;
        private bool _isChecking;

        public string CurrentVersion => Assembly.GetExecutingAssembly().GetName().Version?.ToString() ?? "1.0.0";
        public int CheckIntervalMs { get; set; } = 60000; // 1분

        private UpdateService() { }

        /// <summary>
        /// 주기적 업데이트 체크 시작
        /// </summary>
        public void StartPeriodicCheck()
        {
            _timer = new Timer(async _ => await CheckAndUpdateAsync(), null, 0, CheckIntervalMs);
            LogService.Instance.Log($"[UpdateService] 주기적 업데이트 체크 시작 ({CheckIntervalMs / 1000}초)");
        }

        /// <summary>
        /// 주기적 체크 중지
        /// </summary>
        public void StopPeriodicCheck()
        {
            _timer?.Dispose();
            _timer = null;
        }

        /// <summary>
        /// Squirrel을 통한 GitHub Releases 자동 업데이트
        /// </summary>
        public async Task<bool> CheckAndUpdateAsync()
        {
            if (_isChecking) return false;
            _isChecking = true;

            try
            {
                LogService.Instance.Log("[UpdateService] 업데이트 확인 중...");

                using (var mgr = new UpdateManager(GlobalConfig.GitHubUpdateUrl))
                {
                    var updateInfo = await mgr.CheckForUpdate();

                    if (updateInfo?.ReleasesToApply?.Count > 0)
                    {
                        var newVersion = updateInfo.FutureReleaseEntry?.Version?.ToString();
                        LogService.Instance.Log($"[UpdateService] 새 버전 발견: {newVersion}");

                        await mgr.UpdateApp();
                        LogService.Instance.Log("[UpdateService] 업데이트 완료. 재시작 중...");

                        UpdateManager.RestartApp();
                        return true;
                    }
                    else
                    {
                        LogService.Instance.Log("[UpdateService] 최신 버전입니다.");
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.Instance.Log($"[UpdateService] 업데이트 확인 실패: {ex.Message}");
            }
            finally
            {
                _isChecking = false;
            }
            return false;
        }

        /// <summary>
        /// 앱 시작 시 Squirrel 이벤트 처리
        /// </summary>
        public static void HandleSquirrelEvents()
        {
            SquirrelAwareApp.HandleEvents(
                onInitialInstall: OnAppInstall,
                onAppUpdate: OnAppUpdate,
                onAppUninstall: OnAppUninstall
            );
        }

        private static void OnAppInstall(SemanticVersion version, IAppTools tools)
        {
            tools.CreateShortcutForThisExe(ShortcutLocation.StartMenu | ShortcutLocation.Startup);
            RegistryService.Instance.RegisterUninstaller();
        }

        private static void OnAppUpdate(SemanticVersion version, IAppTools tools)
        {
            tools.CreateShortcutForThisExe(ShortcutLocation.StartMenu | ShortcutLocation.Startup);
        }

        private static void OnAppUninstall(SemanticVersion version, IAppTools tools)
        {
            tools.RemoveShortcutForThisExe(ShortcutLocation.StartMenu | ShortcutLocation.Startup);
            RegistryService.Instance.UnregisterStartup();
            RegistryService.Instance.UnregisterUninstaller();
        }

        private static void OnFirstRun()
        {
            LogService.Instance.Log("첫 실행 - 설치 완료");
        }
    }
}
